import react from 'react'
import { DotLottieReact } from '@lottiefiles/dotlottie-react';

const Loading = () => {

    return (
        <div className='w-28 m-auto flex flex-col gap-2 items-center'>
            <DotLottieReact
                src="https://lottie.host/663cf919-c47b-4e93-977a-9bfb4c2aed29/YbpDSLzsGR.lottie"
                loop
                autoplay
            />
            <span className='text-sm text-gray-500 font-semibold'>LOADING...</span>
        </div>
    )
}

export default Loading;