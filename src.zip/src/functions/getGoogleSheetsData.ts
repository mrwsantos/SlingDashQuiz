import { google } from 'googleapis';

export default async function getGoogleSheetsData(spreadsheetId: string, range: string, key: string) {
    const auth = new google.auth.GoogleAuth({
        keyFile: key,
        scopes: ['https://script.google.com/macros/s/AKfycbyh_6xRw-W9OnIGrtUyJrSmneRS2Td4FP5VTDo_zLO30mvEOWNoB1vLlEmVzFjFUQg/exec']
    });

    const sheets = google.sheets({ version: 'v4', auth });
    const res = await sheets.spreadsheets.values.get({
        spreadsheetId: spreadsheetId,
        range: range,
    });
    return res.data.values;
}