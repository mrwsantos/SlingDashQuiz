'use client'

import { useEffect, useRef, useState } from "react";


import { Geist, Geist_Mono } from "next/font/google";
import Button from "@/components/Button";
import Input from "@/components/Input";
import Loading from "@/components/Loading";

import { useParams } from 'next/navigation';
import Footer from "@/components/Footer";
import getGoogleSheetsData from "@/functions/getGoogleSheetsData";
// import getGoogleSheetsData from "@/functions/getGoogleSheetsData";
const keyword_extractor = require("keyword-extractor");

// const geistSans = Geist({
//     variable: "--font-geist-sans",
//     subsets: ["latin"],
// });

// const geistMono = Geist_Mono({
//     variable: "--font-geist-mono",
//     subsets: ["latin"],
// });

const questions = [
    {
        name: 'Purpose',
        question: 'Why does this brand exist?'
    },
    {
        name: 'The rational proposition or boilerplate',
        question: 'What exactly does your business do?'
    },
    {
        name: 'Audience definition',
        question: 'Who are we talking to?'
    },
]

export default function Home() {
    const params = useParams();
    const id = params.id;

    const title = 'SlingDash Brand Questionnaire';

    const [loading, setLoading] = useState<boolean>(false);
    const [step, setStep] = useState<number>(0);
    const [fade, setFade] = useState<'fade-in' | 'fade-out'>('fade-in');
    const [keyWords, setKeyWords] = useState<string>('')

    const [answers, setAnswers] = useState<string[]>(Array(questions.length).fill(''));

    const getGoogleData = async () => {
        const sheetId = '1wuNyaFGEB1HQtpvYE94xPObCYFEWTT0nx7zTPux22c8';
        const range = 'Sheet1!A:E';
        const key = 'AIzaSyChnWjXqREumhU-tBRSrmFWBK_-1A4yAg0';

        const posts = await getGoogleSheetsData(sheetId, range, key);
    }

    const handleStepChange = (direction: 'next' | 'back') => {
        setFade('fade-out');
        setTimeout(() => {
            setStep(prev => direction === 'next' ? prev + 1 : prev - 1);
            setFade('fade-in');
        }, 300);
    };

    const handleAnswerChange = (value: string) => {
        setAnswers(prev => {
            const updated = [...prev];
            updated[step] = value;
            return updated;
        });
    };

    const getKeyWords = () => {
        const extraction_result =
            keyword_extractor.extract(answers.join(' '), {
                language: "english",
                remove_digits: true,
                return_changed_case: true,
                remove_duplicates: false
            });
        setKeyWords(extraction_result)
    }

    useEffect(() => {
        console.log('keywords: ', keyWords)
    }, [keyWords])
    useEffect(() => {
        console.log('id: ', id)
    }, [id])



    // if (loading) return <Loading />
    return (
        <main className="home">
            {/* <p>id {id}</p> */}
            <h1 className="text-center p-4 text-white text-md bg-gray-800">{title}</h1>
            <form
                action=""
                className={`flex flex-col gap-8 pt-20 pb-20 `}
                id="form"
            >
                <div className={`formContent flex flex-col gap-8 ${fade}`}>
                    <h3 className="text-gray-500 uppercase m-auto text-center">
                        {questions[step].name}
                    </h3>

                    <Input
                        label={`
              ${questions[step].question}`}
                        placeholder="Enter your message here"
                        value={answers[step]}
                        onChange={handleAnswerChange}
                        multiline
                    />


                    {step < questions.length - 1 ? (
                        <Button
                            customStyle="border-1 bg-white w-fit px-8 m-auto hover:bg-gray-100"
                            text="Next Question"
                            onClick={(e: any) => {
                                e.preventDefault();
                                if (step < questions.length - 1) {
                                    handleStepChange('next');
                                }
                            }}
                            disabled={step >= questions.length - 1}
                            type="button"
                        />
                    ) : (
                        <Button
                            customStyle="border-1 bg-white w-fit px-8 m-auto hover:bg-gray-100"
                            text="Submit Form"
                            onClick={(e: any) => {
                                e.preventDefault();
                                // if (step < questions.length - 1) {
                                //   handleStepChange('next');
                                // }
                                getKeyWords();
                                setLoading(true)
                            }}
                            disabled={loading} s
                        // type="submit"
                        />
                    )}


                </div>
                <div className="formFooter">
                    {loading && <Loading />}
                </div>
            </form>

            <Footer length={questions.length} step={step} handleStepChange={handleStepChange} />
        </main>
    );
}
