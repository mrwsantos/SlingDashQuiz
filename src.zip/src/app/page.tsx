'use client'

import { useState } from "react";
import { useRouter } from 'next/navigation';

import Button from "@/components/Button";
import Input from "@/components/Input";

import { Send } from "@deemlol/next-icons";

const Main = () => {
  const [googleSheetId, setGoogleSheetId] = useState<string>('')
  const router = useRouter()

  return (
    <main className="main p-8 flex flex-col gap-8 justify-center" >
      <h1 className="text-4xl text-center p-2">Welcome to SlingDash</h1>
      <div className="flex flex-col gap-4">

        <Input
          label="Please input below the id of your Google Sheets"
          placeholder="Enter your sheet ID"
          value={googleSheetId}
          onChange={setGoogleSheetId}
        />

        <Button
          text="Access"
          customStyle="bg-blue-500 text-white w-fit p-8 rounded-lg mx-auto flex gap-2"
          onClick={() => router.push(`/${googleSheetId}`)}>
          <Send size={24} color="#FFFFFF" />
        </Button>
      </div>



    </main>
  );

}

export default Main
