interface PageProps {
    params: {
        id: string;
    };
}

export default function Page({ params }: PageProps) {
    const { id } = params;

    return (
        <main className="p-8">
            <h1 className="text-2xl font-bold">Result for ID: {id}</h1>
        </main>
    );
}
